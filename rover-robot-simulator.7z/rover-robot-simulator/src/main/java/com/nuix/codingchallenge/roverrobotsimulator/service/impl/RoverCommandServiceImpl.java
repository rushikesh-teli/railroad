package com.nuix.codingchallenge.roverrobotsimulator.service.impl;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.nuix.codingchallenge.roverrobotsimulator.domain.Direction;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommand;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommandDetails;
import com.nuix.codingchallenge.roverrobotsimulator.service.RoverCommandService;

@Service
public class RoverCommandServiceImpl implements RoverCommandService {

	@Override
	public InputStream readCommandFromFile(String fileName) throws Exception {
		InputStream inputStream = new FileInputStream(fileName);
		return inputStream;
	}

	@Override
	public List<String> readCommands(InputStream inputStream) throws IOException {
		List<String> roverCommands = new ArrayList<>();
		String roverCommand;
		try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, Charset.forName(StandardCharsets.UTF_8.name())))) {
            if (inputStream != null) {
                while (!StringUtils.isEmpty(roverCommand = reader.readLine())) {
                	roverCommands.add(roverCommand);
                }
            }
		}
		return roverCommands;
	}

	@Override
	public RoverCommandDetails parseCommand(String roverCommandRecord) {
		String[] roverCommandOptions = roverCommandRecord.split("\\s+");
		RoverCommandDetails roverCommandDetails = new RoverCommandDetails();
		RoverCommand roverCommand = RoverCommand.valueOf(StringUtils.trimToEmpty(roverCommandOptions[0]));
		roverCommandDetails.setRoverCommand(roverCommand);

		String[] commandArgs;
		switch (roverCommand) {
		case DEPLOY:
			commandArgs = roverCommandOptions[1].split(ARG_SEPARATOR);
			if (commandArgs !=null && commandArgs.length == 3) {
				roverCommandDetails.setxValue(Integer.valueOf(commandArgs[0]));
				roverCommandDetails.setyValue(Integer.valueOf(commandArgs[1]));
				Direction direction = Direction.valueOf(StringUtils.trimToEmpty(commandArgs[2]));
				roverCommandDetails.setDirection(direction);
			}
			break;
		case PIT:
			commandArgs = roverCommandOptions[1].split(ARG_SEPARATOR);
			if (commandArgs !=null && commandArgs.length == 2) {
				roverCommandDetails.setxValue(Integer.valueOf(commandArgs[0]));
				roverCommandDetails.setyValue(Integer.valueOf(commandArgs[1]));
			}
		default:
			break;
		}
		return roverCommandDetails;
	}
}
