package com.nuix.codingchallenge.roverrobotsimulator.domain;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class RoverOutput {

	private RoverPosition roverCurrentPosition;
	private List<PitPosition> pitPositions;
	private List<String> output;

	public RoverOutput() {
		this.pitPositions = new ArrayList<>();
		this.output = new ArrayList<>();
	}

	public RoverPosition getRoverCurrentPosition() {
		return roverCurrentPosition;
	}
	public void setRoverCurrentPosition(RoverPosition roverCurrentPosition) {
		this.roverCurrentPosition = roverCurrentPosition;
	}
	public List<PitPosition> getPitPositions() {
		return pitPositions;
	}
	public void setPitPositions(List<PitPosition> pitPositions) {
		this.pitPositions = pitPositions;
	}
	public boolean isRoverDeployed() {
		return this.roverCurrentPosition != null && this.roverCurrentPosition.getDirection() != null;
	}
	public List<String> getOutput() {
		return output;
	}
	public void setOutput(List<String> output) {
		this.output = output;
	}
	@Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
    @Override
    public boolean equals(Object other) {
        return EqualsBuilder.reflectionEquals(this, other);
    }
    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }
}