package com.nuix.codingchallenge.roverrobotsimulator.domain;

import com.nuix.codingchallenge.roverrobotsimulator.exception.UnSupportedInputException;

public enum Direction {
	EAST,
	WEST,
	SOUTH,
	NORTH;

	public static Direction turnLeft(Direction direction) {
		Direction newDirection;
		switch (direction) {
		case EAST:
			newDirection = NORTH;
			break;
		case NORTH:
			newDirection = WEST;
			break;
		case WEST:
			newDirection = SOUTH;
			break;
		case SOUTH:
			newDirection = EAST;
			break;
		default:
			throw new UnSupportedInputException("Invalid Direction");
		}
		return newDirection;
	}

	public static Direction turnRight(Direction direction) {
		Direction newDirection;
		switch (direction) {
		case EAST:
			newDirection = SOUTH;
			break;
		case SOUTH:
			newDirection = WEST;
			break;
		case WEST:
			newDirection = NORTH;
			break;
		case NORTH:
			newDirection = EAST;
			break;
		default:
			throw new UnSupportedInputException("Invalid Direction");
		}
		return newDirection;
	}
}
