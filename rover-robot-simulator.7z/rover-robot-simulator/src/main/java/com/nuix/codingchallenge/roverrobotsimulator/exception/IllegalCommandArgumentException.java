package com.nuix.codingchallenge.roverrobotsimulator.exception;

/**
 * This exception will be thrown for invalid or missing arguments.
 */
public class IllegalCommandArgumentException extends Exception {
    private static final long serialVersionUID = -348166824825682102L;

    public IllegalCommandArgumentException(String message) {
        super(message);
    }
}
