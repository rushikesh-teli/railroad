package com.nuix.codingchallenge.roverrobotsimulator.component;

import java.io.InputStream;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommand;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommandDetails;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverOutput;
import com.nuix.codingchallenge.roverrobotsimulator.service.RoverCommandService;

@Component
public class RobotSimulator {

	@Autowired
	private RoverCommandService roverCommandService;

	@Autowired
    private RoverCommandHandlerFactory roverCommandHandlerFactory;

    /**
     * Should process the input and return the report lines as result.
     *
     * @param input the input.
     * @return the reported lines.
     */
    public List<String> process(InputStream inputStream) throws Exception {
    	RoverOutput roverOutput = new RoverOutput();
    	List<String> roverCommands = roverCommandService.readCommands(inputStream);
    	for (String roverCommand : roverCommands) {
    		RoverCommandDetails roverCommandDetails = roverCommandService.parseCommand(roverCommand);
    		if (RoverCommand.REPORT.equals(roverCommandDetails.getRoverCommand())) {
    			roverOutput.getOutput().add(roverOutput.getRoverCurrentPosition().toString());
    			break;
    		}
    		RoverCommandHandler roverCommandHandler = roverCommandHandlerFactory
    				.getRecordHandler(roverCommandDetails.getRoverCommand());
    		if (roverCommandHandler != null && roverCommandHandler.isValidCommand(roverCommandDetails)) {
    			roverOutput = roverCommandHandler.execute(roverOutput, roverCommandDetails);
    		}
    	}
    	return roverOutput.getOutput();
    }
}