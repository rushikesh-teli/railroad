package com.nuix.codingchallenge.roverrobotsimulator.component;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommand;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommandDetails;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverOutput;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverPosition;
import com.nuix.codingchallenge.roverrobotsimulator.validator.ConstraintValidator;

@Component
public class DeployCommandHandler implements RoverCommandHandler {

	@Autowired
	private ConstraintValidator constraintValidator;

	@Override
	public boolean isValidCommand(RoverCommandDetails roverCommandDetails) {
		return RoverCommand.DEPLOY.equals(roverCommandDetails.getRoverCommand())
				&& roverCommandDetails.getDirection() != null
					&& roverCommandDetails.getxValue() != null
						&& roverCommandDetails.getyValue() != null;
	}

	@Override
	public RoverOutput execute(RoverOutput roverOutput, RoverCommandDetails roverCommandDetails) {
		RoverPosition roverPosition = new RoverPosition(roverCommandDetails.getxValue(), roverCommandDetails.getyValue(), roverCommandDetails.getDirection());

		if (!constraintValidator.isRoverWithinBoundaries(roverPosition)) {
			roverOutput.getOutput().add(constraintValidator.getBoundaryError());
			return roverOutput;
		}
		roverOutput.setRoverCurrentPosition(roverPosition);
		roverOutput.setPitPositions(new ArrayList<>());
		return roverOutput;
	}
}
