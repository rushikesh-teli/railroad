package com.nuix.codingchallenge.roverrobotsimulator.component;

import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommand;

/**
 * A factory interface for handling different rover commands.
 * Note: This interface should never be implemented.
 * It is using a {@link org.springframework.beans.factory.FactoryBean} to create an implement via dynamic proxying.
 *
 * @see FactoryBeanConfig
 */
public interface RoverCommandHandlerFactory {

    /**
     * Factory method to get rover command handler from command type.
     * @param roverCommand rover command to be handled.
     * @return rover command handler for given type.
     */
    RoverCommandHandler getRecordHandler(RoverCommand roverCommand);
}
