package com.nuix.codingchallenge.roverrobotsimulator;

import java.io.InputStream;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.SimpleCommandLinePropertySource;

import com.nuix.codingchallenge.roverrobotsimulator.component.RobotSimulator;
import com.nuix.codingchallenge.roverrobotsimulator.exception.IllegalCommandArgumentException;
import com.nuix.codingchallenge.roverrobotsimulator.service.RoverCommandService;

@SpringBootApplication
@Profile("!testing")
public class RoverRobotSimulator implements CommandLineRunner {

	private static Logger LOG = LoggerFactory.getLogger(RoverRobotSimulator.class);
	private static final String COMMAND_FILE = "commandFile";

	@Autowired
	private RoverCommandService roverCommandService;

	@Autowired
	private RobotSimulator robotSimulator;

	private String commandFilePath;

	public static void main(String[] args) {
        SpringApplication.run(RoverRobotSimulator.class, args);
    }

	@Override
	public void run(String... args) {
		LOG.info("Started Rover Robot Simuator");
        try {
			parseCommandOptions(args);
			InputStream inputDataStream = roverCommandService.readCommandFromFile(commandFilePath);
			List<String> output = robotSimulator.process(inputDataStream);
			output.forEach(System.out::println);
	    } catch (IllegalCommandArgumentException ex) {
	        LOG.error(ex.getMessage());
	    } catch (Throwable th) {
	        LOG.error("The Rover Robot Simuator has exited abnormally", th);
	    }
		LOG.info("Ended Rover Robot Simuator");
	}

	/**
	 * Parses all command options.
	 *
	 * @param args array of command options
	 * @throws IllegalCommandArgumentException is thrown when the command options
	 *                                         are invalid or missing.
	 */
	private void parseCommandOptions(String... args) throws IllegalCommandArgumentException {
		SimpleCommandLinePropertySource commandLinePropertySource = new SimpleCommandLinePropertySource(args);

		commandFilePath = commandLinePropertySource.getProperty(COMMAND_FILE);
		if (StringUtils.isEmpty(commandFilePath)) {
			StringBuilder sb = new StringBuilder();
			sb.append("The Rover Robot Simuator has exited due to invalid arguments.\n")
					.append("\nThe arguments should include: \n")
					.append("     --commandFile  The file path containig commands for rover\n");

			throw new IllegalCommandArgumentException(sb.toString());
		}
		LOG.info("Running Rover Robot Simuator with COMMANDS FROM {}", commandFilePath);
	}
}
