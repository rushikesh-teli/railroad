package com.nuix.codingchallenge.roverrobotsimulator.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nuix.codingchallenge.roverrobotsimulator.domain.PitPosition;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommand;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommandDetails;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverOutput;
import com.nuix.codingchallenge.roverrobotsimulator.validator.ConstraintValidator;

@Component
public class PitCommandHandler implements RoverCommandHandler {

	@Autowired
	private ConstraintValidator constraintValidator;

	@Override
	public boolean isValidCommand(RoverCommandDetails roverCommandDetails) {
		return RoverCommand.PIT.equals(roverCommandDetails.getRoverCommand())
				&& roverCommandDetails.getxValue() != null
					&& roverCommandDetails.getyValue() != null;
	}

	@Override
	public RoverOutput execute(RoverOutput roverOutput,
			RoverCommandDetails roverCommandDetails) {
		if(!roverOutput.isRoverDeployed()) {
			roverOutput.getOutput().add(constraintValidator.getBoundaryError());
			return roverOutput;
		}
		PitPosition pitPosition = new PitPosition(roverCommandDetails.getxValue(), roverCommandDetails.getyValue());

		if(constraintValidator.isPitOnRoverPosition(roverOutput.getRoverCurrentPosition(), pitPosition)) {
			roverOutput.getOutput().add(constraintValidator.getRobotError());
			return roverOutput;
		}
		roverOutput.getPitPositions().add(pitPosition);
		return roverOutput;
	}
}