package com.nuix.codingchallenge.roverrobotsimulator.domain;

public enum RoverCommand {
	DEPLOY,
	PIT,
	MOVE,
	LEFT,
	RIGHT,
	REPORT;
}
