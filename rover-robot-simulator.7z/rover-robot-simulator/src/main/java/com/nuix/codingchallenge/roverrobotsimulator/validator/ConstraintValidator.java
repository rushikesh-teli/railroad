package com.nuix.codingchallenge.roverrobotsimulator.validator;

import java.util.List;

import org.springframework.stereotype.Component;

import com.nuix.codingchallenge.roverrobotsimulator.domain.PitPosition;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverPosition;

@Component
public class ConstraintValidator {

	private static final int LOWER_LIMIT= 0;
	private static final int UPPER_LIMIT= 10;
	private static final String BOUNDARY_ERROR = "Outside Zone: Ignored";
	private static final String PIT_ERROR = "PIT Detected: Ignored";
	private static final String ROBOT_ERROR = "ROBOT Detected: Ignored";

	public boolean isRoverWithinBoundaries(RoverPosition roverPosition) {
		return roverPosition.getxPosition() >= LOWER_LIMIT &&
				roverPosition.getxPosition() <= UPPER_LIMIT &&
				roverPosition.getyPosition() >= LOWER_LIMIT &&
				roverPosition.getyPosition() <= UPPER_LIMIT;
	}

	public boolean isFallingOnPit(RoverPosition roverPosition, List<PitPosition> pitPositions) {
		return pitPositions.stream()
				.anyMatch(pit -> roverPosition.getxPosition() == pit.getxPosition() &&
						roverPosition.getyPosition() == pit.getyPosition());
	}

	public boolean isPitOnRoverPosition(RoverPosition roverPosition, PitPosition pitPosition) {
		return roverPosition.getxPosition() == pitPosition.getxPosition()
				&& roverPosition.getyPosition() == pitPosition.getyPosition();
	}

	public String getBoundaryError() {
		return BOUNDARY_ERROR;
	}

	public String getPitError() {
		return PIT_ERROR;
	}

	public String getRobotError() {
		return ROBOT_ERROR;
	}
}
