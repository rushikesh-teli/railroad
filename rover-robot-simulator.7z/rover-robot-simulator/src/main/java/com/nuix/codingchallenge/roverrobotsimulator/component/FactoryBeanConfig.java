package com.nuix.codingchallenge.roverrobotsimulator.component;

import java.util.Properties;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.config.ServiceLocatorFactoryBean;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommand;

@Configuration
public class FactoryBeanConfig {

    @Autowired
    private DefaultListableBeanFactory defaultBeanFactory;

    @Bean
    public FactoryBean roverCommandFactoryBean(Properties serviceMappings) {
        ServiceLocatorFactoryBean factoryBean = new ServiceLocatorFactoryBean();
        factoryBean.setServiceLocatorInterface(RoverCommandHandlerFactory.class);
        factoryBean.setServiceMappings(serviceMappings);
        factoryBean.afterPropertiesSet();
        return factoryBean;
    }

    @Bean
    @Qualifier("serviceMappings")
    public Properties serviceMappings() {
        Properties serviceMappings = new Properties();
        serviceMappings.setProperty(RoverCommand.DEPLOY.name(), getBeanNameForType(DeployCommandHandler.class));
        serviceMappings.setProperty(RoverCommand.LEFT.name(), getBeanNameForType(TurnCommandHandler.class));
        serviceMappings.setProperty(RoverCommand.RIGHT.name(), getBeanNameForType(TurnCommandHandler.class));
        serviceMappings.setProperty(RoverCommand.MOVE.name(), getBeanNameForType(MoveCommandHandler.class));
        serviceMappings.setProperty(RoverCommand.PIT.name(), getBeanNameForType(PitCommandHandler.class));
        return serviceMappings;
    }

    private String getBeanNameForType(Class<? extends RoverCommandHandler> roverCommandHandler) {
        String[] beanNames = defaultBeanFactory.getBeanNamesForType(roverCommandHandler);
        if (beanNames.length != 1) {
            throw new NoUniqueBeanDefinitionException(roverCommandHandler, beanNames);
        }
        return beanNames[0];
    }
}