package com.nuix.codingchallenge.roverrobotsimulator.component;

import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommandDetails;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverOutput;

/**
 * Generic interface to handle rover commands..
 * Individual specific command handler can implement process method.
 */
public interface RoverCommandHandler {

	/**
	 * Checks if rover command is valid before execution.
	 * @param roverCommandDetails details of rover command to be validated.
	 * @return whether it's valid or not.
	 */
	boolean isValidCommand(RoverCommandDetails roverCommandDetails);

	/**
	 * Executes and updates output of rover command.
	 * @param roverOutput output.
	 * @param roverCommandDetails rover command.
	 * @return updated rover output.
	 */
	RoverOutput execute(RoverOutput roverOutput, RoverCommandDetails roverCommandDetails);
}