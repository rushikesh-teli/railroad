package com.nuix.codingchallenge.roverrobotsimulator.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nuix.codingchallenge.roverrobotsimulator.domain.Direction;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommand;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommandDetails;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverOutput;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverPosition;
import com.nuix.codingchallenge.roverrobotsimulator.validator.ConstraintValidator;

@Component
public class MoveCommandHandler implements RoverCommandHandler {

	@Autowired
	private ConstraintValidator constraintValidator;

	@Override
	public boolean isValidCommand(RoverCommandDetails roverCommandDetails) {
		return RoverCommand.MOVE.equals(roverCommandDetails.getRoverCommand());
	}

	@Override
	public RoverOutput execute(RoverOutput roverOutput,
			RoverCommandDetails roverCommandDetails) {
		if(!roverOutput.isRoverDeployed()) {
			roverOutput.getOutput().add(constraintValidator.getBoundaryError());
			return roverOutput;
		}
		RoverPosition roverCurrentPosition = roverOutput.getRoverCurrentPosition();
		RoverPosition roverNewPosition = new RoverPosition(roverCurrentPosition.getxPosition(), roverCurrentPosition.getyPosition(), roverCurrentPosition.getDirection());
		int newPosition;
		Direction currentDirection = roverCurrentPosition.getDirection();
			switch (currentDirection) {
			case EAST:
				newPosition = roverCurrentPosition.getxPosition() + 1;
				roverNewPosition.setxPosition(newPosition);
				break;
			case WEST:
				newPosition = roverCurrentPosition.getxPosition() - 1;
				roverNewPosition.setxPosition(newPosition);
				break;
			case NORTH:
				newPosition = roverCurrentPosition.getyPosition() + 1;
				roverNewPosition.setyPosition(newPosition);
				break;
			case SOUTH:
				newPosition = roverCurrentPosition.getyPosition() - 1;
				roverNewPosition.setyPosition(newPosition);
				break;
			default:
				break;
			}

		if (!constraintValidator.isRoverWithinBoundaries(roverNewPosition)) {
			roverOutput.getOutput().add(constraintValidator.getBoundaryError());
			return roverOutput;
		}
		if (constraintValidator.isFallingOnPit(roverNewPosition, roverOutput.getPitPositions())) {
			roverOutput.getOutput().add(constraintValidator.getPitError());
			return roverOutput;
		}
		roverOutput.setRoverCurrentPosition(roverNewPosition);
		return roverOutput;
	}
}