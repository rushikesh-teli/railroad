package com.nuix.codingchallenge.roverrobotsimulator.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommandDetails;

/**
 * Interface for reading rover commands.
 */
public interface RoverCommandService {

	String ARG_SEPARATOR = ",";

	/**
	 * @param fileName input file
	 * @return {@link InputStream} of command file.
	 * @throws Exception when reading input file.
	 */
	InputStream readCommandFromFile(String fileName) throws Exception;

	/**
	 * 
	 * @param inputStream {@link InputStream} of command file.
	 * @return list of rover commands.
	 * @throws IOException Exception when reading input stream.
	 */
	List<String> readCommands(InputStream inputStream) throws IOException;
	
	/**
	 * 
	 * @param roverCommandRecord command in string format.
	 * @return {@link RoverCommandDetails} parsed command.
	 */
	RoverCommandDetails parseCommand(String roverCommandRecord);
}
