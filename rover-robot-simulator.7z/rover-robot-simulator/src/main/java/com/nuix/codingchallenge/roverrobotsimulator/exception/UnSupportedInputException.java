package com.nuix.codingchallenge.roverrobotsimulator.exception;

public class UnSupportedInputException extends RuntimeException {

	private static final long serialVersionUID = 5147188029075508244L;
	
	public UnSupportedInputException(String message) {
		super(message);
	}
}
