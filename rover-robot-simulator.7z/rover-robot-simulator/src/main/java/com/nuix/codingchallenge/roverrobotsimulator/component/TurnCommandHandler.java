package com.nuix.codingchallenge.roverrobotsimulator.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nuix.codingchallenge.roverrobotsimulator.domain.Direction;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommand;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommandDetails;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverOutput;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverPosition;
import com.nuix.codingchallenge.roverrobotsimulator.validator.ConstraintValidator;

@Component
public class TurnCommandHandler implements RoverCommandHandler {

	@Autowired
	private ConstraintValidator constraintValidator;

	@Override
	public boolean isValidCommand(RoverCommandDetails roverCommandDetails) {
		return RoverCommand.LEFT.equals(roverCommandDetails.getRoverCommand())
				|| RoverCommand.RIGHT.equals(roverCommandDetails.getRoverCommand());
	}

	@Override
	public RoverOutput execute(RoverOutput roverOutput,
			RoverCommandDetails roverCommandDetails) {
		if(!roverOutput.isRoverDeployed()) {
			roverOutput.getOutput().add(constraintValidator.getBoundaryError());
			return roverOutput;
		}
		RoverPosition roverCurrentPosition = roverOutput.getRoverCurrentPosition();
		RoverPosition roverNewPosition = new RoverPosition(roverCurrentPosition.getxPosition(),
				roverCurrentPosition.getyPosition(), roverCurrentPosition.getDirection());
		Direction newDirection;
		RoverCommand roverCommand = roverCommandDetails.getRoverCommand();
		if(RoverCommand.LEFT.equals(roverCommand)){
			newDirection = Direction.turnLeft(roverCurrentPosition.getDirection());
		} else {
			newDirection = Direction.turnRight(roverCurrentPosition.getDirection());
		}

		roverNewPosition.setDirection(newDirection);
		roverOutput.setRoverCurrentPosition(roverNewPosition);
		return roverOutput;
	}
}