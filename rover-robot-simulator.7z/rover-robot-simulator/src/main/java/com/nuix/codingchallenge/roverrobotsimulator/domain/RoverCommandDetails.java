package com.nuix.codingchallenge.roverrobotsimulator.domain;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class RoverCommandDetails implements Serializable {
	private static final long serialVersionUID = 2401514359560054258L;

	private RoverCommand roverCommand;
	private Integer xValue;
	private Integer yValue;
	private Direction direction;

	public RoverCommand getRoverCommand() {
		return roverCommand;
	}
	public void setRoverCommand(RoverCommand roverCommand) {
		this.roverCommand = roverCommand;
	}
	public Integer getxValue() {
		return xValue;
	}
	public void setxValue(Integer xValue) {
		this.xValue = xValue;
	}
	public Integer getyValue() {
		return yValue;
	}
	public void setyValue(Integer yValue) {
		this.yValue = yValue;
	}
	public Direction getDirection() {
		return direction;
	}
	public void setDirection(Direction direction) {
		this.direction = direction;
	}
	@Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
    @Override
    public boolean equals(Object other) {
        return EqualsBuilder.reflectionEquals(this, other);
    }
    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }
}
