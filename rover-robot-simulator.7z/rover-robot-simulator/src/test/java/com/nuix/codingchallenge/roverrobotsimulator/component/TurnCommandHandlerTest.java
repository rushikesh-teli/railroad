package com.nuix.codingchallenge.roverrobotsimulator.component;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.nuix.codingchallenge.roverrobotsimulator.domain.Direction;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommand;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommandDetails;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverOutput;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverPosition;
import com.nuix.codingchallenge.roverrobotsimulator.validator.ConstraintValidator;

public class TurnCommandHandlerTest {

	@Mock
	private ConstraintValidator constraintValidator;

	@InjectMocks
	private TurnCommandHandler turnCommandHandler;

	private RoverCommandDetails validTurnCommand;
	private RoverCommandDetails inValidTurnCommand;
	private RoverOutput roverOutput;

	@Before
	public void setUp() {
		turnCommandHandler = new TurnCommandHandler();
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testValidCommand() {
		validTurnCommand = getValidRoverCommandDetails();
		Assertions.assertThat(turnCommandHandler.isValidCommand(validTurnCommand))
			.isTrue();

		validTurnCommand.setRoverCommand(RoverCommand.RIGHT);
		Assertions.assertThat(turnCommandHandler.isValidCommand(validTurnCommand))
			.isTrue();
	}

	@Test
	public void testInValidCommand() {
		inValidTurnCommand = getValidRoverCommandDetails();
		inValidTurnCommand.setRoverCommand(null);
		Assertions.assertThat(turnCommandHandler.isValidCommand(inValidTurnCommand))
			.isFalse();
	}

	@Test
	public void testLeftTurnExecuteSuccess() {
		roverOutput = new RoverOutput();
		RoverPosition roverPosition = new RoverPosition(0, 0, Direction.EAST);
		RoverPosition expectedRoverPosition = new RoverPosition(0, 0, Direction.NORTH);
		RoverCommandDetails roverCommandDetails = getValidRoverCommandDetails();
		roverOutput.setRoverCurrentPosition(roverPosition);

		turnCommandHandler.execute(roverOutput, roverCommandDetails);
		Assertions.assertThat(roverOutput.getRoverCurrentPosition()).isEqualToComparingFieldByField(expectedRoverPosition);
	}

	@Test
	public void testRightTurnExecuteSuccess() {
		roverOutput = new RoverOutput();
		RoverPosition roverPosition = new RoverPosition(0, 0, Direction.EAST);
		RoverPosition expectedRoverPosition = new RoverPosition(0, 0, Direction.SOUTH);
		RoverCommandDetails roverCommandDetails = getValidRoverCommandDetails();
		roverCommandDetails.setRoverCommand(RoverCommand.RIGHT);
		roverOutput.setRoverCurrentPosition(roverPosition);

		turnCommandHandler.execute(roverOutput, roverCommandDetails);
		Assertions.assertThat(roverOutput.getRoverCurrentPosition()).isEqualToComparingFieldByField(expectedRoverPosition);
	}

	@Test
	public void testTurnExecuteIgnored() {
		RoverCommandDetails roverCommandDetails = getValidRoverCommandDetails();
		roverOutput = new RoverOutput();
		Mockito.when(constraintValidator.getBoundaryError()).thenReturn("ERROR");
		turnCommandHandler.execute(roverOutput, roverCommandDetails);
		Assertions.assertThat(roverOutput.getOutput()).hasSize(1);
		Assertions.assertThat(roverOutput.getOutput().get(0)).isEqualTo("ERROR");
	}

	private RoverCommandDetails getValidRoverCommandDetails() {
		RoverCommandDetails validTurnCommand = new RoverCommandDetails();
		validTurnCommand.setRoverCommand(RoverCommand.LEFT);
		return validTurnCommand;
	}
}
