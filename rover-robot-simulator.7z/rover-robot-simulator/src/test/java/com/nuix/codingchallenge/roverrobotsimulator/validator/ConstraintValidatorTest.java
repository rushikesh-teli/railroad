package com.nuix.codingchallenge.roverrobotsimulator.validator;

import java.util.Arrays;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;

import com.nuix.codingchallenge.roverrobotsimulator.domain.Direction;
import com.nuix.codingchallenge.roverrobotsimulator.domain.PitPosition;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverPosition;

public class ConstraintValidatorTest {

	private static final String BOUNDARY_ERROR = "Outside Zone: Ignored";
	private static final String PIT_ERROR = "PIT Detected: Ignored";
	private static final String ROBOT_ERROR = "ROBOT Detected: Ignored";
	private ConstraintValidator constraintValidator;

	@Before
	public void setUp() {
		constraintValidator = new ConstraintValidator();
	}

	@Test
	public void testRoverWithinBoundaries() {
		RoverPosition roverPosition = new RoverPosition(5, 6, Direction.EAST);
		Assertions.assertThat(constraintValidator.isRoverWithinBoundaries(roverPosition)).isTrue();
	}

	@Test
	public void testFallingOnPit() {
		PitPosition pitPosition1 =new PitPosition(2, 2);
		PitPosition pitPosition2 = new PitPosition(3, 4);
		RoverPosition roverPosition = new RoverPosition(2, 2, Direction.EAST);
		Assertions.assertThat(constraintValidator.isFallingOnPit(roverPosition, Arrays.asList(pitPosition1, pitPosition2))).isTrue();
	}

	@Test
	public void testPitOnRoverPosition() {
		RoverPosition roverPosition = new RoverPosition(2, 2, Direction.EAST);
		PitPosition pitPosition =new PitPosition(2, 2);
		Assertions.assertThat(constraintValidator.isPitOnRoverPosition(roverPosition, pitPosition)).isTrue();
	}

	@Test
	public void testErrorMessages() {
		Assertions.assertThat(constraintValidator.getBoundaryError()).isEqualTo(BOUNDARY_ERROR);
		Assertions.assertThat(constraintValidator.getPitError()).isEqualTo(PIT_ERROR);
		Assertions.assertThat(constraintValidator.getRobotError()).isEqualTo(ROBOT_ERROR);
	}
}
