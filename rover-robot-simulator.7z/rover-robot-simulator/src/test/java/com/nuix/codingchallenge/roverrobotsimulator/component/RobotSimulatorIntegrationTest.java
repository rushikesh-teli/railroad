package com.nuix.codingchallenge.roverrobotsimulator.component;

import java.io.InputStream;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.nuix.codingchallenge.roverrobotsimulator.AppTestConfig;
import com.nuix.codingchallenge.roverrobotsimulator.service.RoverCommandService;
import com.nuix.codingchallenge.roverrobotsimulator.service.impl.RoverCommandServiceImpl;

@SpringBootTest(classes = AppTestConfig.class)
@RunWith(SpringJUnit4ClassRunner.class)
public class RobotSimulatorIntegrationTest {

	@Autowired
	private RobotSimulator robotSimulator;

	@Autowired
	private RoverCommandService roverCommandService;

	private InputStream inputStream;

	@Before
    public void setup() throws Exception {
		roverCommandService = new RoverCommandServiceImpl();
	}

	@Test
	public void testProcess() throws Exception {
		String commandFilePath = getClass().getClassLoader().getResource("testdata/commands1.txt").getPath();
		inputStream = roverCommandService.readCommandFromFile(commandFilePath);
		List<String> output = robotSimulator.process(inputStream);
		Assertions.assertThat(output).hasSize(1);
	}
}
