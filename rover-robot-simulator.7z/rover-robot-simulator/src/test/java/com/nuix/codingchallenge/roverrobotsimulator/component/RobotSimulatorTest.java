package com.nuix.codingchallenge.roverrobotsimulator.component;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.nuix.codingchallenge.roverrobotsimulator.domain.Direction;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommand;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommandDetails;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverOutput;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverPosition;
import com.nuix.codingchallenge.roverrobotsimulator.service.RoverCommandService;

public class RobotSimulatorTest {

	@Mock
	private RoverCommandService roverCommandService;
	
	@Mock
	private RoverCommandHandlerFactory roverCommandHandlerFactory;
	
	@InjectMocks
	private RobotSimulator robotSimulator;
	
	@Before
	public void setUp() {
		robotSimulator = new RobotSimulator();
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testProcess() throws Exception {
		RoverOutput roverOutput = new RoverOutput();
		roverOutput.setRoverCurrentPosition(new RoverPosition(0, 0, Direction.EAST));
		InputStream inputDataStream = Mockito.mock(InputStream.class);
		RoverCommandDetails roverCommandDetails1 = Mockito.mock(RoverCommandDetails.class);
		RoverCommand roverCommand1 = RoverCommand.DEPLOY;
		Mockito.when(roverCommandDetails1.getRoverCommand()).thenReturn(roverCommand1);
		RoverCommandDetails roverCommandDetails2 = Mockito.mock(RoverCommandDetails.class);
		RoverCommand roverCommand2 = RoverCommand.REPORT;
		Mockito.when(roverCommandDetails2.getRoverCommand()).thenReturn(roverCommand2);
		
		List<String> roverCommands = new ArrayList<>();
		roverCommands.add("COMMAND1");
		roverCommands.add("COMMAND2");
		Mockito.when(roverCommandService.readCommands(inputDataStream)).thenReturn(roverCommands);
		Mockito.when(roverCommandService.parseCommand("COMMAND1")).thenReturn(roverCommandDetails1);
		Mockito.when(roverCommandService.parseCommand("COMMAND2")).thenReturn(roverCommandDetails2);
		
		RoverCommandHandler roverCommandHandler1 = Mockito.mock(RoverCommandHandler.class);
		Mockito.when(roverCommandHandler1.isValidCommand(roverCommandDetails1)).thenReturn(true);
		Mockito.when(roverCommandHandler1.execute(Mockito.any(), Mockito.any())).thenReturn(roverOutput);
		Mockito.when(roverCommandHandlerFactory.getRecordHandler(roverCommand1)).thenReturn(roverCommandHandler1);
		
		robotSimulator.process(inputDataStream);
		Mockito.verify(roverCommandService,Mockito.atMostOnce()).readCommands(inputDataStream);
		Mockito.verify(roverCommandService).parseCommand("COMMAND1");
		Mockito.verify(roverCommandService).parseCommand("COMMAND2");
		Mockito.verify(roverCommandHandlerFactory).getRecordHandler(roverCommand1);
	}
}
