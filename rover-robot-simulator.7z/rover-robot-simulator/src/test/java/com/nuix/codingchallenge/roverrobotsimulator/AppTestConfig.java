package com.nuix.codingchallenge.roverrobotsimulator;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ActiveProfiles;

@ComponentScan(basePackages = { "com.nuix.codingchallenge.roverrobotsimulator" })
@EnableConfigurationProperties
@ActiveProfiles("testing")
public class AppTestConfig {

}
