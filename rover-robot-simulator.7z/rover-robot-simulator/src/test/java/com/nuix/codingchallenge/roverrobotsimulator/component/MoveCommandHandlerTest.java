package com.nuix.codingchallenge.roverrobotsimulator.component;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.nuix.codingchallenge.roverrobotsimulator.domain.Direction;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommand;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommandDetails;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverOutput;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverPosition;
import com.nuix.codingchallenge.roverrobotsimulator.validator.ConstraintValidator;

public class MoveCommandHandlerTest {

	@Mock
	private ConstraintValidator constraintValidator;

	@InjectMocks
	private MoveCommandHandler moveCommandHandler;

	private RoverCommandDetails validMoveCommand;
	private RoverCommandDetails inValidMoveCommand;
	private RoverOutput roverOutput;

	@Before
	public void setUp() {
		moveCommandHandler = new MoveCommandHandler();
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testValidCommand() {
		validMoveCommand = getValidRoverCommandDetails();
		Assertions.assertThat(moveCommandHandler.isValidCommand(validMoveCommand))
			.isTrue();
	}

	@Test
	public void testInValidCommand() {
		inValidMoveCommand = getValidRoverCommandDetails();
		inValidMoveCommand.setRoverCommand(null);
		Assertions.assertThat(moveCommandHandler.isValidCommand(inValidMoveCommand))
			.isFalse();
	}

	@Test
	public void testMoveEastExecuteSuccess() {
		roverOutput = new RoverOutput();
		RoverPosition roverPosition = new RoverPosition(0, 0, Direction.EAST);
		roverOutput.setRoverCurrentPosition(roverPosition);
		RoverPosition expectedRoverPosition = new RoverPosition(1, 0, Direction.EAST);
		RoverCommandDetails roverCommandDetails = getValidRoverCommandDetails();
		roverOutput.setRoverCurrentPosition(roverPosition);

		Mockito.when(constraintValidator.isRoverWithinBoundaries(Mockito.any())).thenReturn(true);
		Mockito.when(constraintValidator.isFallingOnPit(Mockito.any(), Mockito.anyList())).thenReturn(false);
		moveCommandHandler.execute(roverOutput, roverCommandDetails);
		Assertions.assertThat(roverOutput.getRoverCurrentPosition()).isEqualToComparingFieldByField(expectedRoverPosition);
	}

	@Test
	public void testMoveNorthExecuteSuccess() {
		roverOutput = new RoverOutput();
		RoverPosition roverPosition = new RoverPosition(1, 0, Direction.NORTH);
		roverOutput.setRoverCurrentPosition(roverPosition);
		RoverPosition expectedRoverPosition = new RoverPosition(1, 1, Direction.NORTH);
		RoverCommandDetails roverCommandDetails = getValidRoverCommandDetails();
		roverOutput.setRoverCurrentPosition(roverPosition);

		Mockito.when(constraintValidator.isRoverWithinBoundaries(Mockito.any())).thenReturn(true);
		Mockito.when(constraintValidator.isFallingOnPit(Mockito.any(), Mockito.anyList())).thenReturn(false);
		moveCommandHandler.execute(roverOutput, roverCommandDetails);
		Assertions.assertThat(roverOutput.getRoverCurrentPosition()).isEqualToComparingFieldByField(expectedRoverPosition);
	}

	@Test
	public void testMoveWestExecuteSuccess() {
		roverOutput = new RoverOutput();
		RoverPosition roverPosition = new RoverPosition(2, 0, Direction.WEST);
		roverOutput.setRoverCurrentPosition(roverPosition);
		RoverPosition expectedRoverPosition = new RoverPosition(1, 0, Direction.WEST);
		RoverCommandDetails roverCommandDetails = getValidRoverCommandDetails();
		roverOutput.setRoverCurrentPosition(roverPosition);

		Mockito.when(constraintValidator.isRoverWithinBoundaries(Mockito.any())).thenReturn(true);
		Mockito.when(constraintValidator.isFallingOnPit(Mockito.any(), Mockito.anyList())).thenReturn(false);
		moveCommandHandler.execute(roverOutput, roverCommandDetails);
		Assertions.assertThat(roverOutput.getRoverCurrentPosition()).isEqualToComparingFieldByField(expectedRoverPosition);
	}

	@Test
	public void testSouthEastExecuteSuccess() {
		roverOutput = new RoverOutput();
		RoverPosition roverPosition = new RoverPosition(0, 4, Direction.SOUTH);
		roverOutput.setRoverCurrentPosition(roverPosition);
		RoverPosition expectedRoverPosition = new RoverPosition(0, 3, Direction.SOUTH);
		RoverCommandDetails roverCommandDetails = getValidRoverCommandDetails();
		roverOutput.setRoverCurrentPosition(roverPosition);

		Mockito.when(constraintValidator.isRoverWithinBoundaries(Mockito.any())).thenReturn(true);
		Mockito.when(constraintValidator.isFallingOnPit(Mockito.any(), Mockito.anyList())).thenReturn(false);
		moveCommandHandler.execute(roverOutput, roverCommandDetails);
		Assertions.assertThat(roverOutput.getRoverCurrentPosition()).isEqualToComparingFieldByField(expectedRoverPosition);
	}

	@Test
	public void testMoveExecuteIgnored() {
		RoverCommandDetails roverCommandDetails = getValidRoverCommandDetails();
		roverOutput = new RoverOutput();
		Mockito.when(constraintValidator.getBoundaryError()).thenReturn("ERROR");
		moveCommandHandler.execute(roverOutput, roverCommandDetails);
		Assertions.assertThat(roverOutput.getOutput()).hasSize(1);
		Assertions.assertThat(roverOutput.getOutput().get(0)).isEqualTo("ERROR");
	}

	@Test
	public void testMoveExecuteBoundaryError() {
		roverOutput = new RoverOutput();
		RoverPosition roverPosition = new RoverPosition(0, 4, Direction.SOUTH);
		roverOutput.setRoverCurrentPosition(roverPosition);
		RoverCommandDetails roverCommandDetails = getValidRoverCommandDetails();
		roverOutput.setRoverCurrentPosition(roverPosition);

		Mockito.when(constraintValidator.isRoverWithinBoundaries(Mockito.any())).thenReturn(false);
		Mockito.when(constraintValidator.getBoundaryError()).thenReturn("ERROR");
		moveCommandHandler.execute(roverOutput, roverCommandDetails);
		Assertions.assertThat(roverOutput.getOutput()).hasSize(1);
		Assertions.assertThat(roverOutput.getOutput().get(0)).isEqualTo("ERROR");
		Assertions.assertThat(roverOutput.getRoverCurrentPosition()).isEqualToComparingFieldByField(roverPosition);
	}

	@Test
	public void testMoveExecutePitError() {
		roverOutput = new RoverOutput();
		RoverPosition roverPosition = new RoverPosition(0, 4, Direction.SOUTH);
		roverOutput.setRoverCurrentPosition(roverPosition);
		RoverCommandDetails roverCommandDetails = getValidRoverCommandDetails();
		roverOutput.setRoverCurrentPosition(roverPosition);

		Mockito.when(constraintValidator.isRoverWithinBoundaries(Mockito.any())).thenReturn(true);
		Mockito.when(constraintValidator.isFallingOnPit(Mockito.any(), Mockito.anyList())).thenReturn(true);
		Mockito.when(constraintValidator.getPitError()).thenReturn("ERROR");
		moveCommandHandler.execute(roverOutput, roverCommandDetails);
		Assertions.assertThat(roverOutput.getOutput()).hasSize(1);
		Assertions.assertThat(roverOutput.getOutput().get(0)).isEqualTo("ERROR");
		roverOutput.setRoverCurrentPosition(roverPosition);
	}

	private RoverCommandDetails getValidRoverCommandDetails() {
		RoverCommandDetails validMoveCommand = new RoverCommandDetails();
		validMoveCommand.setRoverCommand(RoverCommand.MOVE);
		return validMoveCommand;
	}
}
