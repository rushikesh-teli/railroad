package com.nuix.codingchallenge.roverrobotsimulator.component;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.junit4.SpringRunner;

import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommand;
import com.nuix.codingchallenge.roverrobotsimulator.service.RoverCommandService;
import com.nuix.codingchallenge.roverrobotsimulator.validator.ConstraintValidator;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { RoverCommandHandlerFactoryTest.TestConfig.class, FactoryBeanConfig.class })
public class RoverCommandHandlerFactoryTest {

    @MockBean
    private ConstraintValidator constraintValidator;

    @MockBean
    private RoverCommandService roverCommandService;

    @Configuration
    @ComponentScan("com.nuix.codingchallenge.roverrobotsimulator.component")
    public static class TestConfig {
    }

    @Autowired
    private RoverCommandHandlerFactory roverCommandHandlerFactory;

    @Test
    public void testDeployCommandHandler() {
        assertThat(roverCommandHandlerFactory.getRecordHandler(RoverCommand.DEPLOY))
            .isInstanceOf(DeployCommandHandler.class);
    }

    @Test
    public void testPitCommandHandler() {
        assertThat(roverCommandHandlerFactory.getRecordHandler(RoverCommand.PIT))
            .isInstanceOf(PitCommandHandler.class);
    }

    @Test
    public void testMoveCommandHandler() {
        assertThat(roverCommandHandlerFactory.getRecordHandler(RoverCommand.MOVE))
            .isInstanceOf(MoveCommandHandler.class);
    }

    @Test
    public void testLeftTurnCommandHandler() {
        assertThat(roverCommandHandlerFactory.getRecordHandler(RoverCommand.LEFT))
            .isInstanceOf(TurnCommandHandler.class);
    }

    @Test
    public void testRightTurnCommandHandler() {
        assertThat(roverCommandHandlerFactory.getRecordHandler(RoverCommand.RIGHT))
            .isInstanceOf(TurnCommandHandler.class);
    }
}