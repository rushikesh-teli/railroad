package com.nuix.codingchallenge.roverrobotsimulator.component;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.nuix.codingchallenge.roverrobotsimulator.domain.Direction;
import com.nuix.codingchallenge.roverrobotsimulator.domain.PitPosition;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommand;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommandDetails;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverOutput;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverPosition;
import com.nuix.codingchallenge.roverrobotsimulator.validator.ConstraintValidator;

public class PitCommandHandlerTest {

	@Mock
	private ConstraintValidator constraintValidator;

	@InjectMocks
	private PitCommandHandler pitCommandHandler;

	private RoverCommandDetails validPitCommand;
	private RoverCommandDetails inValidPitCommand;
	private RoverOutput roverOutput;

	@Before
	public void setUp() {
		pitCommandHandler = new PitCommandHandler();
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testValidCommand() {
		validPitCommand = new RoverCommandDetails();
		validPitCommand.setRoverCommand(RoverCommand.PIT);
		validPitCommand.setxValue(0);
		validPitCommand.setyValue(0);

		Assertions.assertThat(pitCommandHandler.isValidCommand(validPitCommand))
			.isTrue();
	}

	@Test
	public void testInValidCommand() {
		inValidPitCommand = getValidRoverCommandDetails();
		inValidPitCommand.setRoverCommand(null);
		Assertions.assertThat(pitCommandHandler.isValidCommand(inValidPitCommand))
			.isFalse();
		inValidPitCommand = getValidRoverCommandDetails();
		inValidPitCommand.setxValue(null);
		Assertions.assertThat(pitCommandHandler.isValidCommand(inValidPitCommand))
			.isFalse();
		inValidPitCommand = getValidRoverCommandDetails();
		inValidPitCommand.setyValue(null);
		Assertions.assertThat(pitCommandHandler.isValidCommand(inValidPitCommand))
			.isFalse();
	}

	@Test
	public void testPitExecuteSuccess() {
		roverOutput = new RoverOutput();
		RoverPosition roverPosition = new RoverPosition(0, 0, Direction.EAST);
		RoverCommandDetails roverCommandDetails = getValidRoverCommandDetails();
		roverOutput.setRoverCurrentPosition(roverPosition);
		PitPosition expectedPitPosition = new PitPosition(0, 1);

		Mockito.when(constraintValidator.isPitOnRoverPosition(Mockito.any(), Mockito.any())).thenReturn(false);
		pitCommandHandler.execute(roverOutput, roverCommandDetails);
		Assertions.assertThat(roverOutput.getPitPositions().get(0)).isEqualToComparingFieldByField(expectedPitPosition);
		Assertions.assertThat(roverOutput.getPitPositions()).hasSize(1);
	}

	@Test
	public void testPitExecuteError() {
		RoverPosition roverPosition = new RoverPosition(1, 0, Direction.EAST);
		RoverCommandDetails roverCommandDetails = getValidRoverCommandDetails();
		roverOutput = new RoverOutput();
		roverOutput.setRoverCurrentPosition(roverPosition);
		Mockito.when(constraintValidator.isPitOnRoverPosition(Mockito.any(), Mockito.any())).thenReturn(true);
		Mockito.when(constraintValidator.getRobotError()).thenReturn("ERROR");
		pitCommandHandler.execute(roverOutput, roverCommandDetails);
		Assertions.assertThat(roverOutput.getPitPositions()).isEmpty();
		Assertions.assertThat(roverOutput.getOutput()).hasSize(1);
		Assertions.assertThat(roverOutput.getOutput().get(0)).isEqualTo("ERROR");
	}

	@Test
	public void testPitExecuteIgnored() {
		RoverCommandDetails roverCommandDetails = getValidRoverCommandDetails();
		roverOutput = new RoverOutput();
		Mockito.when(constraintValidator.isPitOnRoverPosition(Mockito.any(), Mockito.any())).thenReturn(true);
		Mockito.when(constraintValidator.getBoundaryError()).thenReturn("ERROR");
		pitCommandHandler.execute(roverOutput, roverCommandDetails);
		Assertions.assertThat(roverOutput.getPitPositions()).isEmpty();
		Assertions.assertThat(roverOutput.getOutput()).hasSize(1);
		Assertions.assertThat(roverOutput.getOutput().get(0)).isEqualTo("ERROR");
	}

	private RoverCommandDetails getValidRoverCommandDetails() {
		RoverCommandDetails validPitCommand = new RoverCommandDetails();
		validPitCommand.setRoverCommand(RoverCommand.PIT);
		validPitCommand.setxValue(0);
		validPitCommand.setyValue(1);
		return validPitCommand;
	}
}
