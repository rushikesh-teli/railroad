package com.nuix.codingchallenge.roverrobotsimulator;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.nuix.codingchallenge.roverrobotsimulator.component.RobotSimulator;
import com.nuix.codingchallenge.roverrobotsimulator.service.RoverCommandService;

public class RoverRobotSimulatorTest {

	@Mock
	private RoverCommandService roverCommandService;

	@Mock
	private RobotSimulator robotSimulator;
	
	@InjectMocks
	private RoverRobotSimulator roverRobotSimulator;
	
	private String commandFilePath = "mockfile";
	
	@Before
	public void setUp() {
		roverRobotSimulator = new RoverRobotSimulator();
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testRunSuccess() throws Exception {
		InputStream inputDataStream = Mockito.mock(InputStream.class);
		List<String> output = new ArrayList<>();
		Mockito.when(roverCommandService.readCommandFromFile(commandFilePath)).thenReturn(inputDataStream);
		Mockito.when(robotSimulator.process(inputDataStream)).thenReturn(output);
		
		roverRobotSimulator.run("--commandFile=mockfile");
		
		Mockito.verify(roverCommandService).readCommandFromFile(commandFilePath);
		Mockito.verify(robotSimulator).process(inputDataStream);
	}

	@Test
	public void testRunFailure() throws Exception {
		InputStream inputDataStream = Mockito.mock(InputStream.class);
		List<String> output = new ArrayList<>();
		Mockito.when(roverCommandService.readCommandFromFile(commandFilePath)).thenReturn(inputDataStream);
		Mockito.when(robotSimulator.process(inputDataStream)).thenReturn(output);
		
		roverRobotSimulator.run("");
		
		Mockito.verify(roverCommandService, Mockito.never()).readCommandFromFile(commandFilePath);
		Mockito.verify(robotSimulator, Mockito.never()).process(inputDataStream);
	}
}
