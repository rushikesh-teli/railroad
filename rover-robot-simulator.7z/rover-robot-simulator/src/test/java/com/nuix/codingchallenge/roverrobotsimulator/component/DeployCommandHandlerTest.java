package com.nuix.codingchallenge.roverrobotsimulator.component;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.nuix.codingchallenge.roverrobotsimulator.domain.Direction;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommand;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommandDetails;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverOutput;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverPosition;
import com.nuix.codingchallenge.roverrobotsimulator.validator.ConstraintValidator;

public class DeployCommandHandlerTest {

	@Mock
	private ConstraintValidator constraintValidator;

	@InjectMocks
	private DeployCommandHandler deployCommandHandler;

	private RoverCommandDetails validDeployCommand;
	private RoverCommandDetails inValidDeployCommand;
	private RoverOutput roverOutput;

	@Before
	public void setUp() {
		deployCommandHandler = new DeployCommandHandler();
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testValidCommand() {
		validDeployCommand = new RoverCommandDetails();
		validDeployCommand.setRoverCommand(RoverCommand.DEPLOY);
		validDeployCommand.setxValue(0);
		validDeployCommand.setyValue(0);
		validDeployCommand.setDirection(Direction.EAST);

		Assertions.assertThat(deployCommandHandler.isValidCommand(validDeployCommand))
			.isTrue();
	}

	@Test
	public void testInValidCommand() {
		inValidDeployCommand = getValidRoverCommandDetails();
		inValidDeployCommand.setRoverCommand(null);
		Assertions.assertThat(deployCommandHandler.isValidCommand(inValidDeployCommand))
			.isFalse();
		inValidDeployCommand = getValidRoverCommandDetails();
		inValidDeployCommand.setxValue(null);
		Assertions.assertThat(deployCommandHandler.isValidCommand(inValidDeployCommand))
			.isFalse();
		inValidDeployCommand = getValidRoverCommandDetails();
		inValidDeployCommand.setyValue(null);
		Assertions.assertThat(deployCommandHandler.isValidCommand(inValidDeployCommand))
			.isFalse();
		inValidDeployCommand = getValidRoverCommandDetails();
		inValidDeployCommand.setDirection(null);
		Assertions.assertThat(deployCommandHandler.isValidCommand(inValidDeployCommand))
			.isFalse();
	}

	@Test
	public void testDeployExecuteSuccess() {
		RoverPosition roverPosition = new RoverPosition(0, 0, Direction.EAST);
		RoverCommandDetails roverCommandDetails = getValidRoverCommandDetails();
		roverOutput = new RoverOutput();
		Mockito.when(constraintValidator.isRoverWithinBoundaries(roverPosition)).thenReturn(true);
		deployCommandHandler.execute(roverOutput, roverCommandDetails);
		Assertions.assertThat(roverOutput.getRoverCurrentPosition()).isEqualToComparingFieldByField(roverPosition);
		Assertions.assertThat(roverOutput.getPitPositions()).isEmpty();
	}

	@Test
	public void testDeployExecuteError() {
		RoverPosition roverPosition = new RoverPosition(11, 0, Direction.EAST);
		RoverCommandDetails roverCommandDetails = getValidRoverCommandDetails();
		roverOutput = new RoverOutput();
		Mockito.when(constraintValidator.isRoverWithinBoundaries(roverPosition)).thenReturn(false);
		Mockito.when(constraintValidator.getBoundaryError()).thenReturn("ERROR");
		deployCommandHandler.execute(roverOutput, roverCommandDetails);
		Assertions.assertThat(roverOutput.getRoverCurrentPosition()).isNull();
		Assertions.assertThat(roverOutput.getPitPositions()).isEmpty();
		Assertions.assertThat(roverOutput.getOutput()).hasSize(1);
		Assertions.assertThat(roverOutput.getOutput().get(0)).isEqualTo("ERROR");
	}

	private RoverCommandDetails getValidRoverCommandDetails() {
		RoverCommandDetails validDeployCommand = new RoverCommandDetails();
		validDeployCommand.setRoverCommand(RoverCommand.DEPLOY);
		validDeployCommand.setxValue(0);
		validDeployCommand.setyValue(0);
		validDeployCommand.setDirection(Direction.EAST);
		return validDeployCommand;
	}
}