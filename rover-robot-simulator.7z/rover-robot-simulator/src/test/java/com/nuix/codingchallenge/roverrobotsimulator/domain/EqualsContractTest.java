package com.nuix.codingchallenge.roverrobotsimulator.domain;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import nl.jqno.equalsverifier.EqualsVerifier;
import nl.jqno.equalsverifier.Warning;

/**
 * Verify the equals contract across our objects is met
 */
@RunWith(Parameterized.class)
public class EqualsContractTest {
    /** The class to test. */
    private final Class<Object> testClass;

    /**
     * Init prefab fields
     */
    @Before
    public void setUp() {
    }

    /**
     * Construct a junit test to check the equals contract for a given class.
     * @param testClass - the class to test.
     */
    public EqualsContractTest(final Class<Object> testClass) {
        this.testClass = testClass;
    }

    /**
     *  Parameters to perform the test with.
     * @return a list of the classes to test.
     * */
    @SuppressWarnings("rawtypes")
    @Parameters(name = "{index}: TestEqualsContract({0})")
    public static List<Class> data() {
        return Arrays.asList(new Class[] {
        	RoverCommandDetails.class,
        	RoverOutput.class,
        	RoverPosition.class,
        	PitPosition.class
        });
    }

    @Test
    public void testEqualsContract() {
        EqualsVerifier.forClass(testClass)
                      .suppress(Warning.STRICT_INHERITANCE)
                      .suppress(Warning.NONFINAL_FIELDS)
                      .suppress(Warning.TRANSIENT_FIELDS)
                      .withRedefinedSuperclass()
                      .verify();
    }
}
