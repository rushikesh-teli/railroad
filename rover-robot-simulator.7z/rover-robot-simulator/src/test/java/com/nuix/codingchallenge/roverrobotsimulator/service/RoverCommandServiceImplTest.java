package com.nuix.codingchallenge.roverrobotsimulator.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;

import com.nuix.codingchallenge.roverrobotsimulator.domain.Direction;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommand;
import com.nuix.codingchallenge.roverrobotsimulator.domain.RoverCommandDetails;
import com.nuix.codingchallenge.roverrobotsimulator.service.impl.RoverCommandServiceImpl;

public class RoverCommandServiceImplTest {

	private RoverCommandService roverCommandService;
	private InputStream inputStream;

	@Before
    public void setup() throws Exception {
		roverCommandService = new RoverCommandServiceImpl();
		String commandFilePath = getClass().getClassLoader().getResource("testdata/commands1.txt").getPath();
		inputStream = roverCommandService.readCommandFromFile(commandFilePath);
	}

	@Test
	public void testReadCommands() throws IOException {
		List<String> commands = roverCommandService.readCommands(inputStream);
		Assertions.assertThat(commands).hasSize(3);
	}

	@Test
	public void testParseDeployCommand() {
		String deployCommand = "DEPLOY 1,3,NORTH";
		RoverCommandDetails roverCommandDetails = roverCommandService.parseCommand(deployCommand);
		RoverCommandDetails expectedRoverCommandDetails = new RoverCommandDetails();
		expectedRoverCommandDetails.setRoverCommand(RoverCommand.DEPLOY);
		expectedRoverCommandDetails.setxValue(1);
		expectedRoverCommandDetails.setyValue(3);
		expectedRoverCommandDetails.setDirection(Direction.NORTH);

		Assertions.assertThat(roverCommandDetails).isEqualToComparingFieldByField(expectedRoverCommandDetails);
	}

	@Test
	public void testParsePitCommand() {
		String deployCommand = "PIT 1,3";
		RoverCommandDetails roverCommandDetails = roverCommandService.parseCommand(deployCommand);
		RoverCommandDetails expectedRoverCommandDetails = new RoverCommandDetails();
		expectedRoverCommandDetails.setRoverCommand(RoverCommand.PIT);
		expectedRoverCommandDetails.setxValue(1);
		expectedRoverCommandDetails.setyValue(3);

		Assertions.assertThat(roverCommandDetails).isEqualToComparingFieldByField(expectedRoverCommandDetails);
	}

	@Test
	public void testParseMoveCommand() {
		String deployCommand = "MOVE";
		RoverCommandDetails roverCommandDetails = roverCommandService.parseCommand(deployCommand);
		RoverCommandDetails expectedRoverCommandDetails = new RoverCommandDetails();
		expectedRoverCommandDetails.setRoverCommand(RoverCommand.MOVE);

		Assertions.assertThat(roverCommandDetails).isEqualToComparingFieldByField(expectedRoverCommandDetails);
	}
}
